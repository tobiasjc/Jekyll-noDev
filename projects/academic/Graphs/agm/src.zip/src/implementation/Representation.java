package implementation;

public enum Representation {
    MATRIZ_ADJACENCIA,
    LISTA_ADJACENCIA,
    MATRIZ_INCIDENCIA
}
